---
name: Generated client browser libs
description: TypeScript settings required by Orval-generated browser clients.
---

Generated API clients may call `Headers.entries()`, so the client library TypeScript `lib` list must include `dom.iterable` alongside `dom`.

**Why:** Without `dom.iterable`, the generated client fails the workspace library typecheck even though code generation itself succeeds.

**How to apply:** Preserve `dom.iterable` in `lib/api-client-react/tsconfig.json` when regenerating or reworking the shared client.