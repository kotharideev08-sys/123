import { useLocation, Link } from 'wouter';
import { ArrowUpRight, CircleDollarSign, LayoutDashboard, Plus, UsersRound } from 'lucide-react';
import type { ReactNode } from 'react';

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const isGroups = location === '/groups';
  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-[250px] flex-col bg-sidebar px-5 py-7 text-sidebar-foreground md:flex">
        <Link href="/" className="mb-14 flex items-center gap-3" data-testid="link-brand">
          <span className="grid h-10 w-10 place-items-center rounded-[13px] bg-primary text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))]">
            <CircleDollarSign size={21} strokeWidth={2.2} />
          </span>
          <span className="font-serif text-[22px] font-bold tracking-[-0.03em]">student split</span>
        </Link>
        <p className="mb-3 px-3 font-mono text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/50">Your space</p>
        <nav className="space-y-1">
          <Link href="/" className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors ${location === '/' ? 'bg-sidebar-accent text-sidebar-foreground' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`} data-testid="link-dashboard">
            <LayoutDashboard size={17} /> Overview
          </Link>
          <Link href="/groups" className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors ${isGroups ? 'bg-sidebar-accent text-sidebar-foreground' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`} data-testid="link-groups">
            <UsersRound size={17} /> All groups
          </Link>
        </nav>
        <div className="mt-auto rounded-2xl border border-sidebar-border bg-sidebar-accent/45 p-4">
          <p className="font-serif text-lg leading-tight">No more “I’ll send it later.”</p>
          <p className="mt-2 text-xs leading-relaxed text-sidebar-foreground/55">Keep the math visible, kind, and out of the group chat.</p>
          <Link href="/groups" className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-primary" data-testid="link-create-group-tip">Start a group <ArrowUpRight size={13} /></Link>
        </div>
      </aside>
      <header className="sticky top-0 z-10 flex h-[68px] items-center justify-between border-b border-border/70 bg-background/90 px-5 backdrop-blur-md md:hidden">
        <Link href="/" className="flex items-center gap-2.5" data-testid="link-mobile-brand">
          <span className="grid h-8 w-8 place-items-center rounded-[10px] bg-primary text-primary-foreground"><CircleDollarSign size={17} /></span>
          <span className="font-serif text-lg font-bold">student split</span>
        </Link>
        <Link href="/groups" className="grid h-9 w-9 place-items-center rounded-full bg-secondary text-foreground" data-testid="link-mobile-add"><Plus size={18} /></Link>
      </header>
      <main className="md:pl-[250px]">
        <div className="mx-auto w-full max-w-[1400px] px-5 py-7 sm:px-8 sm:py-10 lg:px-12">{children}</div>
      </main>
    </div>
  );
}

export function PageKicker({ children }: { children: ReactNode }) {
  return <div className="mb-3 flex items-center gap-2 font-mono text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-primary" />{children}</div>;
}

export function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return <div className="mb-5 flex items-end justify-between gap-4"><div>{eyebrow && <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{eyebrow}</p>}<h2 className="font-serif text-[25px] font-bold tracking-[-0.035em] sm:text-[29px]">{title}</h2></div>{action}</div>;
}

export function EmptyIcon({ children }: { children: ReactNode }) {
  return <div className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-foreground">{children}</div>;
}

export function formatMoney(value: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value);
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(new Date(value));
}

export function initials(name: string) {
  return name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase();
}

export function Avatar({ name, initials: provided, index = 0 }: { name: string; initials?: string; index?: number }) {
  const colors = ['bg-[#d6e8df]', 'bg-[#f8d8c9]', 'bg-[#f7e4a9]', 'bg-[#d9d8ee]'];
  return <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${colors[index % colors.length]} font-mono text-[11px] font-medium text-foreground`} title={name}>{provided || initials(name)}</span>;
}

export const categoryTone: Record<string, string> = {
  Food: 'bg-[#f8d8c9] text-[#9d4d32]',
  Travel: 'bg-[#d6e8df] text-[#2c6b5e]',
  Home: 'bg-[#f7e4a9] text-[#876611]',
  Fun: 'bg-[#d9d8ee] text-[#5e5a8b]',
  Other: 'bg-muted text-muted-foreground',
};