import { useEffect, useRef, type ReactNode } from 'react';
import { ClerkProvider, Show, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Redirect, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import DashboardPage from '@/pages/dashboard';
import GroupsPage from '@/pages/groups';
import GroupDashboardPage from '@/pages/group-dashboard';
import JoinGroupPage from '@/pages/join-group';
import LandingPage from '@/pages/landing';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string) {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#ef8354',
    colorForeground: '#203746',
    colorMutedForeground: '#66747b',
    colorDanger: '#b64d42',
    colorBackground: '#fbfcf8',
    colorInput: '#ffffff',
    colorInputForeground: '#203746',
    colorNeutral: '#dbe4df',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fbfcf8] rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#203746] font-serif',
    headerSubtitle: 'text-[#66747b]',
    socialButtonsBlockButtonText: 'text-[#203746]',
    formFieldLabel: 'text-[#203746]',
    footerActionLink: 'text-[#d8643e] font-semibold',
    footerActionText: 'text-[#66747b]',
    dividerText: 'text-[#66747b]',
    identityPreviewEditButton: 'text-[#d8643e]',
    formFieldSuccessText: 'text-[#2c6b5e]',
    alertText: 'text-[#b64d42]',
    logoBox: 'mb-2',
    logoImage: 'rounded-xl',
    socialButtonsBlockButton: 'border-[#dbe4df] bg-white',
    formButtonPrimary: 'bg-[#ef8354] text-white hover:bg-[#d8643e]',
    formFieldInput: 'border-[#dbe4df] bg-white text-[#203746]',
    footerAction: 'bg-transparent',
    dividerLine: 'bg-[#dbe4df]',
    alert: 'border-[#f1c2b5] bg-[#fff6f2]',
    otpCodeFieldInput: 'border-[#dbe4df] bg-white text-[#203746]',
    formFieldRow: 'text-[#203746]',
    main: 'bg-transparent',
  },
};

function LoadingScreen() {
  return (
    <div className="grid min-h-[100dvh] place-items-center bg-background text-muted-foreground">
      <div className="text-center">
        <div className="mx-auto mb-3 h-10 w-10 animate-pulse rounded-2xl bg-primary/30" />
        <p className="font-mono text-[10px] uppercase tracking-[0.18em]">Loading your campus space</p>
      </div>
    </div>
  );
}

function AuthBoundary({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <LoadingScreen />;
  if (!isSignedIn) return <Redirect to="/" />;
  return <>{children}</>;
}

function HomeRoute() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <LoadingScreen />;
  return isSignedIn ? <DashboardPage /> : <LandingPage />;
}

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function CacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserRef = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserRef.current !== undefined && previousUserRef.current !== userId) {
        client.clear();
      }
      previousUserRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);
  return null;
}

function Router() {
  const [location] = useLocation();
  return (
    <ErrorBoundary resetKey={location}>
      <Switch>
        <Route path="/" component={HomeRoute} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/join/:inviteCode">
          {() => <AuthBoundary><JoinGroupPage /></AuthBoundary>}
        </Route>
        <Route path="/groups">
          {() => <AuthBoundary><GroupsPage /></AuthBoundary>}
        </Route>
        <Route path="/groups/:groupId">
          {() => <AuthBoundary><GroupDashboardPage /></AuthBoundary>}
        </Route>
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function ClerkRoutes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Welcome back', subtitle: 'Sign in to split smarter on campus' } },
        signUp: { start: { title: 'Create your account', subtitle: 'Your campus expenses, finally organized' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <CacheInvalidator />
        <Router />
      </QueryClientProvider>
    </ClerkProvider>
  );
}

export default function App() {
  return (
    <TooltipProvider>
      <WouterRouter base={basePath}>
        <ClerkRoutes />
      </WouterRouter>
      <Toaster />
    </TooltipProvider>
  );
}