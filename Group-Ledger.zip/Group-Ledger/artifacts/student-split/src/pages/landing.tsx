import { ArrowRight, Check, IndianRupee, Link2, PieChart, UsersRound } from 'lucide-react';
import { Link } from 'wouter';

export default function LandingPage() {
  return (
    <main className="min-h-[100dvh] overflow-hidden bg-background text-foreground">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6 sm:px-8">
        <Link href="/" className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-[13px] bg-primary text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))]"><IndianRupee size={21} /></span>
          <span className="font-serif text-xl font-bold tracking-[-0.03em]">Smart Campus</span>
        </Link>
        <div className="flex items-center gap-2">
          <Link href="/sign-in" className="rounded-xl px-4 py-2 text-sm font-bold text-muted-foreground hover:text-foreground">Log in</Link>
          <Link href="/sign-up" className="rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))]">Get started</Link>
        </div>
      </nav>
      <section className="mx-auto grid max-w-6xl gap-12 px-5 pb-20 pt-10 sm:px-8 sm:pt-20 lg:grid-cols-[1.08fr_0.92fr] lg:items-center">
        <div>
          <p className="mb-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-primary"><span className="h-1.5 w-1.5 rounded-full bg-primary" /> Built for campus life</p>
          <h1 className="max-w-3xl font-serif text-5xl font-bold leading-[0.95] tracking-[-0.06em] sm:text-7xl">Split expenses.<br /><span className="text-primary">Keep friendships.</span></h1>
          <p className="mt-7 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">Smart Campus Expense Splitter keeps hostel bills, trips, food runs, and club spends clear in ₹—so “I’ll send it later” doesn’t become a semester-long promise.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/sign-up" className="inline-flex h-12 items-center gap-2 rounded-xl bg-primary px-5 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))] transition-transform hover:-translate-y-0.5">Create your account <ArrowRight size={16} /></Link>
            <Link href="/sign-in" className="inline-flex h-12 items-center rounded-xl border border-border bg-card px-5 text-sm font-bold hover:bg-muted">I already have an account</Link>
          </div>
          <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-xs text-muted-foreground">
            {['Equal or custom splits', 'Invite links', '₹ INR built in'].map((item) => <span key={item} className="inline-flex items-center gap-1.5"><Check size={14} className="text-secondary-foreground" />{item}</span>)}
          </div>
        </div>
        <div className="relative rounded-[30px] bg-sidebar p-6 text-sidebar-foreground shadow-[10px_10px_0_hsl(var(--accent))] sm:p-8">
          <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full border-[24px] border-sidebar-accent/60" />
          <div className="relative">
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-sidebar-foreground/55">A calmer group chat</p>
            <p className="mt-3 font-serif text-3xl font-bold">Hostel Room 302</p>
            <div className="mt-7 rounded-2xl bg-sidebar-accent/70 p-4">
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-sidebar-foreground/55">Your balance</p>
              <p className="mt-1 font-mono text-3xl">₹240.00</p>
              <p className="mt-1 text-xs text-sidebar-foreground/55">You owe Meera for groceries</p>
            </div>
            <div className="mt-4 space-y-2">
              {['₹1,840  Groceries', '₹720  Late-night cab', '₹1,260  Electricity'].map((item) => <div key={item} className="flex items-center justify-between rounded-xl border border-sidebar-border px-3 py-3 text-sm"><span>{item.split('  ')[1]}</span><span className="font-mono text-sidebar-foreground/65">{item.split('  ')[0]}</span></div>)}
            </div>
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-4 px-5 pb-20 sm:grid-cols-3 sm:px-8">
        {[
          [UsersRound, 'One space for the crew', 'Create groups for rooms, trips, clubs, and every plan in between.'],
          [Link2, 'Invite without the awkwardness', 'Share a unique code or link so everyone can join themselves.'],
          [PieChart, 'See where it went', 'Charts make food, travel, stay, and other spending easy to understand.'],
        ].map(([Icon, title, copy]) => {
          const FeatureIcon = Icon as typeof UsersRound;
          return <div key={title as string} className="rounded-2xl border border-border bg-card p-6"><FeatureIcon className="text-primary" size={22} /><h2 className="mt-5 font-serif text-xl font-bold">{title as string}</h2><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{copy as string}</p></div>;
        })}
      </section>
    </main>
  );
}