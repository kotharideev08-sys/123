import { useEffect, useState } from 'react';
import { Check, CircleAlert, LoaderCircle } from 'lucide-react';
import { useLocation, useParams } from 'wouter';
import { useJoinGroup } from '@workspace/api-client-react';

export default function JoinGroupPage() {
  const { inviteCode } = useParams<{ inviteCode: string }>();
  const [, setLocation] = useLocation();
  const joinGroup = useJoinGroup();
  const [started, setStarted] = useState(false);

  useEffect(() => {
    if (!inviteCode || started) return;
    setStarted(true);
    joinGroup.mutate({ inviteCode: inviteCode.toUpperCase() }, {
      onSuccess: (group) => setLocation(`/groups/${group.id}`),
    });
  }, [inviteCode, joinGroup, setLocation, started]);

  return (
    <div className="grid min-h-[100dvh] place-items-center bg-background px-5">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 text-center">
        {joinGroup.isPending && <><LoaderCircle className="mx-auto animate-spin text-primary" size={30} /><h1 className="mt-5 font-serif text-2xl font-bold">Joining your group…</h1><p className="mt-2 text-sm text-muted-foreground">We’re adding you to the shared space.</p></>}
        {joinGroup.isSuccess && <><Check className="mx-auto text-secondary-foreground" size={30} /><h1 className="mt-5 font-serif text-2xl font-bold">You’re in!</h1></>}
        {joinGroup.isError && <><CircleAlert className="mx-auto text-destructive" size={30} /><h1 className="mt-5 font-serif text-2xl font-bold">Invite not available</h1><p className="mt-2 text-sm text-muted-foreground">Ask the group admin for a fresh invite link.</p><button onClick={() => window.location.reload()} className="mt-5 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">Try again</button></>}
      </div>
    </div>
  );
}