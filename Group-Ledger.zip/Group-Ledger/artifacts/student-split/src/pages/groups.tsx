import { useState, type FormEvent } from 'react';
import { useLocation, Link } from 'wouter';
import { ArrowRight, Plus, UsersRound, X } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { getListGroupsQueryKey, useCreateGroup, useListGroups } from '@workspace/api-client-react';
import { AppShell, Avatar, EmptyIcon, formatMoney, PageKicker, SectionTitle } from '@/components/app-shell';

function CreateGroupPanel({ onClose }: { onClose: () => void }) {
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const createGroup = useCreateGroup();
  const [name, setName] = useState('');
  const [mark, setMark] = useState('☼');
  const [members, setMembers] = useState(['']);
  const [error, setError] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const memberNames = members.map((member) => member.trim()).filter(Boolean);
    if (!name.trim() || !memberNames.length) { setError('Add a group name and at least one person.'); return; }
    setError('');
    createGroup.mutate({ data: { name: name.trim(), emoji: mark.trim() || '☼', memberNames } }, {
      onSuccess: async (group) => { await queryClient.invalidateQueries({ queryKey: getListGroupsQueryKey() }); setLocation(`/groups/${group.id}`); },
      onError: () => setError('That did not save. Check your connection and try again.'),
    });
  };
  return <div className="fixed inset-0 z-40 flex items-end justify-center bg-foreground/30 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" role="dialog" aria-modal="true" data-testid="dialog-create-group">
    <form onSubmit={submit} className="w-full max-w-[510px] rounded-t-[26px] bg-card p-6 shadow-2xl sm:rounded-[26px] sm:p-8">
      <div className="mb-7 flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">New shared space</p><h2 className="mt-1 font-serif text-3xl font-bold">Start a group</h2></div><button type="button" onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full bg-muted text-muted-foreground" aria-label="Close" data-testid="button-close-create-group"><X size={17} /></button></div>
      <div className="grid grid-cols-[74px_1fr] gap-3"><label className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Mark<input value={mark} onChange={(event) => setMark(event.target.value)} maxLength={3} className="mt-2 h-12 w-full rounded-xl border border-input bg-background text-center text-xl outline-none ring-primary/20 focus:ring-4" data-testid="input-group-mark" /></label><label className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Group name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Apartment 4B" className="mt-2 h-12 w-full rounded-xl border border-input bg-background px-3 font-sans text-base text-foreground outline-none ring-primary/20 placeholder:text-muted-foreground/60 focus:ring-4" data-testid="input-group-name" /></label></div>
      <div className="mt-6"><div className="mb-2 flex items-center justify-between"><label className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Who’s in it?</label><button type="button" className="text-xs font-bold text-primary" onClick={() => setMembers([...members, ''])} data-testid="button-add-member-field"><Plus size={13} className="mr-1 inline" />Add person</button></div><div className="space-y-2">{members.map((member, index) => <div className="flex gap-2" key={`member-field-${index}`}><input value={member} onChange={(event) => setMembers(members.map((current, currentIndex) => currentIndex === index ? event.target.value : current))} placeholder={index === 0 ? 'Your name' : 'Roommate or friend'} className="h-11 flex-1 rounded-xl border border-input bg-background px-3 text-sm outline-none ring-primary/20 focus:ring-4" data-testid={`input-member-name-${index}`} />{members.length > 1 && <button type="button" className="px-2 text-muted-foreground" onClick={() => setMembers(members.filter((_, currentIndex) => currentIndex !== index))} aria-label="Remove person" data-testid={`button-remove-member-${index}`}><X size={16} /></button>}</div>)}</div></div>
      {error && <p className="mt-4 rounded-xl bg-destructive/10 px-3 py-2 text-sm text-destructive" data-testid="status-create-group-error">{error}</p>}
      <button disabled={createGroup.isPending} className="mt-7 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:opacity-60" data-testid="button-submit-create-group">{createGroup.isPending ? 'Saving your group…' : 'Create group'} <ArrowRight size={17} /></button>
    </form>
  </div>;
}

export default function GroupsPage() {
  const { data: groups, isLoading, isError, refetch } = useListGroups();
  const [showCreate, setShowCreate] = useState(false);
  return <AppShell><div className="mb-10 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><PageKicker>Shared spaces</PageKicker><h1 className="font-serif text-4xl font-bold tracking-[-0.045em] sm:text-5xl">Your groups<span className="text-primary">.</span></h1><p className="mt-3 max-w-[460px] text-sm leading-relaxed text-muted-foreground">Every trip, apartment, and dinner crew in one tidy place.</p></div><button onClick={() => setShowCreate(true)} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-5 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_hsl(var(--accent))] transition-transform hover:-translate-y-0.5" data-testid="button-open-create-group"><Plus size={17} /> New group</button></div>
    {isLoading && <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[1, 2, 3].map((item) => <div key={item} className="h-[205px] animate-pulse rounded-2xl border border-border bg-card/60" />)}</div>}
    {isError && <div className="rounded-2xl border border-destructive/20 bg-destructive/5 p-8 text-center"><p className="font-serif text-xl">We couldn’t load your groups.</p><p className="mt-2 text-sm text-muted-foreground">Your data is safe. Give it another go.</p><button onClick={() => refetch()} className="mt-5 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground" data-testid="button-retry-groups">Try again</button></div>}
    {!isLoading && !isError && groups?.length === 0 && <div className="rounded-3xl border border-dashed border-border bg-card/50 px-6 py-14 text-center"><EmptyIcon><UsersRound size={24} /></EmptyIcon><h2 className="mt-5 font-serif text-2xl font-bold">A clean slate.</h2><p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">Make a group for your place, your next weekend away, or the friends who always forget who paid.</p><button onClick={() => setShowCreate(true)} className="mt-6 inline-flex items-center gap-2 rounded-xl bg-foreground px-5 py-3 text-sm font-bold text-background" data-testid="button-empty-create-group"><Plus size={16} /> Make your first group</button></div>}
    {!!groups?.length && <><SectionTitle eyebrow="All your spaces" title={`${groups.length} ${groups.length === 1 ? 'group' : 'groups'} in the mix`} /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{groups.map((group, index) => <Link href={`/groups/${group.id}`} key={group.id} className="group rounded-2xl border border-border bg-card p-5 shadow-[0_2px_0_hsl(var(--border))] transition-all hover:-translate-y-1 hover:shadow-[0_8px_0_hsl(var(--secondary))]" data-testid={`card-group-${group.id}`}><div className="flex items-start justify-between"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-xl">{group.emoji}</span><ArrowRight size={18} className="text-muted-foreground transition-transform group-hover:translate-x-1" /></div><h3 className="mt-7 font-serif text-2xl font-bold tracking-[-0.03em]">{group.name}</h3><div className="mt-4 flex items-end justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[0.13em] text-muted-foreground">Spent together</p><p className="mt-1 font-mono text-lg">{formatMoney(group.totalSpent)}</p></div><div className="flex -space-x-2">{Array.from({ length: Math.min(group.memberCount, 3) }).map((_, avatarIndex) => <Avatar key={avatarIndex} name={`member ${avatarIndex}`} index={avatarIndex} />)}{group.memberCount > 3 && <span className="grid h-9 w-9 place-items-center rounded-full border-2 border-card bg-muted font-mono text-[10px]">+{group.memberCount - 3}</span>}</div></div></Link>)}</div></>}
    {showCreate && <CreateGroupPanel onClose={() => setShowCreate(false)} />}
  </AppShell>;
}