import { randomBytes } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import {
  AddMemberBody,
  AddMemberParams,
  CreateExpenseBody,
  CreateExpenseParams,
  CreateGroupBody,
  GetGroupDashboardParams,
  JoinGroupParams,
  SettleDebtBody,
  SettleDebtParams,
} from "@workspace/api-zod";
import {
  db,
  expenseParticipantsTable,
  expensesTable,
  groupsTable,
  membersTable,
  settlementsTable,
  usersTable,
  type User,
} from "@workspace/db";
import { requireCurrentUser } from "../auth";

const router: IRouter = Router();

const toInitials = (name: string) =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");

const toAmount = (value: string | number | null | undefined) =>
  Math.round(Number(value ?? 0) * 100) / 100;

const toMember = (member: typeof membersTable.$inferSelect) => ({
  id: member.id,
  groupId: member.groupId,
  userId: member.userId,
  name: member.name,
  email: member.email,
  initials: toInitials(member.name),
  role: member.role,
});

const toIso = (value: Date) => value.toISOString();

function inviteCode() {
  return randomBytes(5).toString("hex").toUpperCase();
}

async function getGroupOrNull(groupId: number) {
  const [group] = await db
    .select()
    .from(groupsTable)
    .where(eq(groupsTable.id, groupId))
    .limit(1);
  return group ?? null;
}

async function getMembership(groupId: number, userId: number) {
  const [member] = await db
    .select()
    .from(membersTable)
    .where(and(eq(membersTable.groupId, groupId), eq(membersTable.userId, userId)))
    .limit(1);
  return member ?? null;
}

async function isAdmin(groupId: number, userId: number) {
  const [group] = await db
    .select({ adminUserId: groupsTable.adminUserId })
    .from(groupsTable)
    .where(eq(groupsTable.id, groupId))
    .limit(1);
  return group?.adminUserId === userId;
}

async function getGroupCard(
  group: typeof groupsTable.$inferSelect,
  actor: User,
) {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(membersTable)
    .where(eq(membersTable.groupId, group.id));
  const [{ total }] = await db
    .select({ total: sql<string>`coalesce(sum(${expensesTable.amount}), 0)` })
    .from(expensesTable)
    .where(eq(expensesTable.groupId, group.id));

  return {
    id: group.id,
    name: group.name,
    emoji: group.emoji,
    inviteCode: group.inviteCode,
    isAdmin: group.adminUserId === actor.id,
    createdAt: toIso(group.createdAt),
    memberCount: Number(count ?? 0),
    totalSpent: toAmount(total),
  };
}

function roundCents(value: number) {
  return Math.round(value * 100) / 100;
}

async function getExpensePayload(
  expense: typeof expensesTable.$inferSelect,
  memberById: Map<number, typeof membersTable.$inferSelect>,
  splitsByExpense: Map<number, Array<{ memberId: number; amount: number }>>,
) {
  const paidBy = memberById.get(expense.paidByMemberId);
  if (!paidBy) throw new Error(`Missing payer for expense ${expense.id}`);
  return {
    id: expense.id,
    groupId: expense.groupId,
    description: expense.description,
    amount: toAmount(expense.amount),
    category: expense.category,
    paidBy: toMember(paidBy),
    splitType: splitsByExpense.get(expense.id)?.length ? "custom" : "equal",
    splits: splitsByExpense.get(expense.id) ?? [],
    createdAt: toIso(expense.createdAt),
  };
}

export async function getDashboard(groupId: number, actor: User) {
  const group = await getGroupOrNull(groupId);
  if (!group || !(await getMembership(groupId, actor.id))) return null;

  const members = await db
    .select()
    .from(membersTable)
    .where(eq(membersTable.groupId, groupId))
    .orderBy(asc(membersTable.id));
  const expenses = await db
    .select()
    .from(expensesTable)
    .where(eq(expensesTable.groupId, groupId))
    .orderBy(desc(expensesTable.createdAt), desc(expensesTable.id));
  const participantRows =
    expenses.length === 0
      ? []
      : await db
          .select()
          .from(expenseParticipantsTable)
          .where(
            inArray(
              expenseParticipantsTable.expenseId,
              expenses.map((expense) => expense.id),
            ),
          );
  const memberById = new Map(members.map((member) => [member.id, member]));
  const splitsByExpense = new Map<number, Array<{ memberId: number; amount: number }>>();
  for (const row of participantRows) {
    const current = splitsByExpense.get(row.expenseId) ?? [];
    current.push({
      memberId: row.memberId,
      amount: toAmount(row.shareAmount),
    });
    splitsByExpense.set(row.expenseId, current);
  }

  const expensePayloads = await Promise.all(
    expenses.map((expense) => getExpensePayload(expense, memberById, splitsByExpense)),
  );
  const netByMember = new Map(members.map((member) => [member.id, 0]));
  const paidByMember = new Map(members.map((member) => [member.id, 0]));
  const owedByMember = new Map(members.map((member) => [member.id, 0]));
  const categoryTotals = new Map<string, number>();

  for (const expense of expenses) {
    const amount = toAmount(expense.amount);
    paidByMember.set(
      expense.paidByMemberId,
      roundCents((paidByMember.get(expense.paidByMemberId) ?? 0) + amount),
    );
    netByMember.set(
      expense.paidByMemberId,
      (netByMember.get(expense.paidByMemberId) ?? 0) + amount,
    );
    const storedSplits = splitsByExpense.get(expense.id) ?? [];
    const equalShare = amount / Math.max(storedSplits.length, 1);
    for (const split of storedSplits) {
      const share = split.amount || equalShare;
      owedByMember.set(
        split.memberId,
        roundCents((owedByMember.get(split.memberId) ?? 0) + share),
      );
      netByMember.set(split.memberId, (netByMember.get(split.memberId) ?? 0) - share);
    }
    categoryTotals.set(
      expense.category,
      roundCents((categoryTotals.get(expense.category) ?? 0) + amount),
    );
  }

  const recordedSettlements = await db
    .select()
    .from(settlementsTable)
    .where(eq(settlementsTable.groupId, groupId));
  for (const settlement of recordedSettlements) {
    netByMember.set(
      settlement.fromMemberId,
      (netByMember.get(settlement.fromMemberId) ?? 0) + Number(settlement.amount),
    );
    netByMember.set(
      settlement.toMemberId,
      (netByMember.get(settlement.toMemberId) ?? 0) - Number(settlement.amount),
    );
  }

  const balances = members.map((member) => ({
    member: toMember(member),
    amount: toAmount(netByMember.get(member.id)),
  }));
  const debtors = balances
    .filter((balance) => balance.amount < -0.005)
    .map((balance) => ({ member: balance.member, amount: -balance.amount }));
  const creditors = balances
    .filter((balance) => balance.amount > 0.005)
    .map((balance) => ({ member: balance.member, amount: balance.amount }));
  const settlements: Array<{
    id: number;
    from: ReturnType<typeof toMember>;
    to: ReturnType<typeof toMember>;
    amount: number;
    settledAt: string;
  }> = [];
  let debtorIndex = 0;
  let creditorIndex = 0;
  while (debtorIndex < debtors.length && creditorIndex < creditors.length) {
    const debtor = debtors[debtorIndex];
    const creditor = creditors[creditorIndex];
    const amount = toAmount(Math.min(debtor.amount, creditor.amount));
    settlements.push({
      id: 0,
      from: debtor.member,
      to: creditor.member,
      amount,
      settledAt: new Date().toISOString(),
    });
    debtor.amount = toAmount(debtor.amount - amount);
    creditor.amount = toAmount(creditor.amount - amount);
    if (debtor.amount < 0.005) debtorIndex += 1;
    if (creditor.amount < 0.005) creditorIndex += 1;
  }

  const totalSpent = toAmount(expensePayloads.reduce((total, expense) => total + expense.amount, 0));
  const categoryBreakdown = [...categoryTotals.entries()]
    .map(([category, amount]) => ({
      category,
      amount: toAmount(amount),
      percentage: totalSpent > 0 ? Math.round((amount / totalSpent) * 1000) / 10 : 0,
    }))
    .sort((a, b) => b.amount - a.amount);
  const memberStats = members.map((member) => ({
    member: toMember(member),
    paid: toAmount(paidByMember.get(member.id)),
    owes: toAmount(owedByMember.get(member.id)),
  }));

  return {
    group: await getGroupCard(group, actor),
    currentUserMemberId: (await getMembership(groupId, actor.id))?.id ?? null,
    members: members.map(toMember),
    expenses: expensePayloads,
    balances,
    settlements,
    categoryBreakdown,
    memberStats,
    totalSpent,
  };
}

router.get("/me", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  res.json({ id: actor.id, name: actor.name, email: actor.email });
});

router.get("/me/summary", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  try {
    const memberships = await db
      .select({ group: groupsTable })
      .from(membersTable)
      .innerJoin(groupsTable, eq(groupsTable.id, membersTable.groupId))
      .where(eq(membersTable.userId, actor.id));
    const groups = [];
    let totalOwed = 0;
    let totalOwedToYou = 0;
    for (const { group } of memberships) {
      const dashboard = await getDashboard(group.id, actor);
      if (!dashboard) continue;
      const balance = dashboard.balances.find(
        (item) => item.member.userId === actor.id,
      )?.amount ?? 0;
      const owed = balance < 0 ? -balance : 0;
      const owedToYou = balance > 0 ? balance : 0;
      totalOwed += owed;
      totalOwedToYou += owedToYou;
      groups.push({
        groupId: group.id,
        groupName: group.name,
        emoji: group.emoji,
        owed: toAmount(owed),
        owedToYou: toAmount(owedToYou),
      });
    }
    res.json({
      user: { id: actor.id, name: actor.name, email: actor.email },
      totalOwed: toAmount(totalOwed),
      totalOwedToYou: toAmount(totalOwedToYou),
      groups,
    });
  } catch (error) {
    req.log.error({ err: error }, "Failed to load personal summary");
    res.status(500).json({ error: "Unable to load your balance summary." });
  }
});

router.get("/groups", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  try {
    const memberships = await db
      .select({ group: groupsTable })
      .from(membersTable)
      .innerJoin(groupsTable, eq(groupsTable.id, membersTable.groupId))
      .where(eq(membersTable.userId, actor.id));
    const seen = new Set<number>();
    const groups = [];
    for (const { group } of memberships) {
      if (seen.has(group.id)) continue;
      seen.add(group.id);
      groups.push(await getGroupCard(group, actor));
    }
    res.json(groups);
  } catch (error) {
    req.log.error({ err: error }, "Failed to list groups");
    res.status(500).json({ error: "Unable to load groups" });
  }
});

router.post("/groups", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  const parsed = CreateGroupBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a group name and choose a group mark." });
    return;
  }
  try {
    const created = await db.transaction(async (tx) => {
      const [group] = await tx
        .insert(groupsTable)
        .values({
          name: parsed.data.name.trim(),
          emoji: parsed.data.emoji,
          inviteCode: inviteCode(),
          adminUserId: actor.id,
        })
        .returning();
      if (!group) throw new Error("Group was not created");
      await tx.insert(membersTable).values({
        groupId: group.id,
        userId: actor.id,
        name: actor.name,
        email: actor.email,
        role: "admin",
      });
      return group;
    });
    res.status(201).json(await getGroupCard(created, actor));
  } catch (error) {
    req.log.error({ err: error }, "Failed to create group");
    res.status(500).json({ error: "Unable to create group" });
  }
});

router.get("/groups/:groupId/dashboard", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  const parsed = GetGroupDashboardParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid group id" });
    return;
  }
  try {
    const dashboard = await getDashboard(parsed.data.groupId, actor);
    if (!dashboard) {
      res.status(404).json({ error: "Group not found" });
      return;
    }
    res.json(dashboard);
  } catch (error) {
    req.log.error({ err: error }, "Failed to load group dashboard");
    res.status(500).json({ error: "Unable to load group dashboard" });
  }
});

router.post("/groups/:groupId/members", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  const params = AddMemberParams.safeParse(req.params);
  const body = AddMemberBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Enter a valid member email." });
    return;
  }
  try {
    if (!(await isAdmin(params.data.groupId, actor.id))) {
      res.status(403).json({ error: "Only the group admin can add members by email." });
      return;
    }
    const email = body.data.email.trim().toLowerCase();
    const existingUser = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email))
      .limit(1);
    const linkedUser = existingUser[0];
    const [member] = await db
      .insert(membersTable)
      .values({
        groupId: params.data.groupId,
        userId: linkedUser?.id ?? null,
        name: linkedUser?.name ?? email.split("@")[0],
        email,
        role: "member",
      })
      .returning();
    if (!member) throw new Error("Member was not added");
    res.status(201).json(toMember(member));
  } catch (error) {
    req.log.error({ err: error }, "Failed to add member");
    res.status(500).json({ error: "Unable to add that member." });
  }
});

router.post("/invites/:inviteCode/join", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  const parsed = JoinGroupParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid invite code." });
    return;
  }
  try {
    const [group] = await db
      .select()
      .from(groupsTable)
      .where(eq(groupsTable.inviteCode, parsed.data.inviteCode.toUpperCase()))
      .limit(1);
    if (!group) {
      res.status(404).json({ error: "That invite is no longer valid." });
      return;
    }
    const existing = await getMembership(group.id, actor.id);
    if (!existing) {
      const [pending] = await db
        .select()
        .from(membersTable)
        .where(and(eq(membersTable.groupId, group.id), eq(membersTable.email, actor.email)))
        .limit(1);
      if (pending) {
        await db
          .update(membersTable)
          .set({ userId: actor.id, name: actor.name })
          .where(eq(membersTable.id, pending.id));
      } else {
        await db.insert(membersTable).values({
          groupId: group.id,
          userId: actor.id,
          name: actor.name,
          email: actor.email,
          role: "member",
        });
      }
    }
    res.json(await getGroupCard(group, actor));
  } catch (error) {
    req.log.error({ err: error }, "Failed to join group");
    res.status(500).json({ error: "Unable to join that group." });
  }
});

router.post("/groups/:groupId/expenses", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  const params = CreateExpenseParams.safeParse(req.params);
  const body = CreateExpenseBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Check the expense details and try again." });
    return;
  }
  const uniqueSplits = [...new Map(body.data.splits.map((split) => [split.memberId, split])).values()];
  try {
    if (!(await getMembership(params.data.groupId, actor.id))) {
      res.status(403).json({ error: "Join this group before adding expenses." });
      return;
    }
    const members = await db
      .select()
      .from(membersTable)
      .where(eq(membersTable.groupId, params.data.groupId));
    const memberIds = new Set(members.map((member) => member.id));
    if (
      !memberIds.has(body.data.paidByMemberId) ||
      uniqueSplits.length === 0 ||
      uniqueSplits.some((split) => !memberIds.has(split.memberId) || split.amount < 0)
    ) {
      res.status(400).json({ error: "Choose valid group members for this expense." });
      return;
    }
    const amountCents = Math.round(body.data.amount * 100);
    const splitAmounts =
      body.data.splitType === "equal"
        ? uniqueSplits.map((split, index) => ({
            memberId: split.memberId,
            amount: (Math.floor(amountCents / uniqueSplits.length) +
              (index < amountCents % uniqueSplits.length ? 1 : 0)) /
              100,
          }))
        : uniqueSplits.map((split) => ({ memberId: split.memberId, amount: roundCents(split.amount) }));
    if (Math.round(splitAmounts.reduce((sum, split) => sum + split.amount, 0) * 100) !== amountCents) {
      res.status(400).json({ error: "Custom shares must add up to the full expense amount." });
      return;
    }

    const created = await db.transaction(async (tx) => {
      const [expense] = await tx
        .insert(expensesTable)
        .values({
          groupId: params.data.groupId,
          description: body.data.description.trim(),
          amount: body.data.amount.toFixed(2),
          category: body.data.category,
          paidByMemberId: body.data.paidByMemberId,
        })
        .returning();
      if (!expense) throw new Error("Expense was not created");
      await tx.insert(expenseParticipantsTable).values(
        splitAmounts.map((split) => ({
          expenseId: expense.id,
          memberId: split.memberId,
          shareAmount: split.amount.toFixed(2),
        })),
      );
      return expense;
    });
    const memberById = new Map(members.map((member) => [member.id, member]));
    res.status(201).json(
      await getExpensePayload(
        created,
        memberById,
        new Map([[created.id, splitAmounts]]),
      ),
    );
  } catch (error) {
    req.log.error({ err: error }, "Failed to create expense");
    res.status(500).json({ error: "Unable to save that expense." });
  }
});

router.post("/groups/:groupId/settlements", async (req, res) => {
  const actor = await requireCurrentUser(req, res);
  if (!actor) return;
  const params = SettleDebtParams.safeParse(req.params);
  const body = SettleDebtBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Check the settlement details and try again." });
    return;
  }
  try {
    if (!(await getMembership(params.data.groupId, actor.id))) {
      res.status(403).json({ error: "You are not a member of this group." });
      return;
    }
    const members = await db
      .select()
      .from(membersTable)
      .where(eq(membersTable.groupId, params.data.groupId));
    const memberById = new Map(members.map((member) => [member.id, member]));
    const from = memberById.get(body.data.fromMemberId);
    const to = memberById.get(body.data.toMemberId);
    if (!from || !to || from.id === to.id) {
      res.status(400).json({ error: "Choose two different group members." });
      return;
    }
    const [settlement] = await db
      .insert(settlementsTable)
      .values({
        groupId: params.data.groupId,
        fromMemberId: from.id,
        toMemberId: to.id,
        amount: body.data.amount.toFixed(2),
      })
      .returning();
    if (!settlement) throw new Error("Settlement was not recorded");
    res.status(201).json({
      id: settlement.id,
      from: toMember(from),
      to: toMember(to),
      amount: toAmount(settlement.amount),
      settledAt: toIso(settlement.createdAt),
    });
  } catch (error) {
    req.log.error({ err: error }, "Failed to record settlement");
    res.status(500).json({ error: "Unable to record that settlement." });
  }
});

export default router;