import { eq, sql } from "drizzle-orm";
import {
  db,
  expenseParticipantsTable,
  expensesTable,
  groupsTable,
  membersTable,
} from "@workspace/db";

export async function ensureDemoData() {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(groupsTable);
  if (Number(count ?? 0) > 0) return;

  await db.transaction(async (tx) => {
    const [group] = await tx
      .insert(groupsTable)
      .values({ name: "Hostel Room 302", emoji: "⌂" })
      .returning();
    if (!group) return;

    const createdMembers = await tx
      .insert(membersTable)
      .values([
        { groupId: group.id, name: "Aarav" },
        { groupId: group.id, name: "Diya" },
        { groupId: group.id, name: "Kabir" },
        { groupId: group.id, name: "Meera" },
      ])
      .returning();
    const byName = new Map(createdMembers.map((member) => [member.name, member]));
    const aarav = byName.get("Aarav");
    const diya = byName.get("Diya");
    const kabir = byName.get("Kabir");
    const meera = byName.get("Meera");
    if (!aarav || !diya || !kabir || !meera) return;

    const [groceries] = await tx
      .insert(expensesTable)
      .values({
        groupId: group.id,
        description: "Groceries & essentials",
        amount: "1840.00",
        category: "Food",
        paidByMemberId: diya.id,
      })
      .returning();
    const [cab] = await tx
      .insert(expensesTable)
      .values({
        groupId: group.id,
        description: "Late-night cab",
        amount: "720.00",
        category: "Travel",
        paidByMemberId: kabir.id,
      })
      .returning();
    const [utilities] = await tx
      .insert(expensesTable)
      .values({
        groupId: group.id,
        description: "Electricity bill",
        amount: "1260.00",
        category: "Utilities",
        paidByMemberId: aarav.id,
      })
      .returning();
    if (!groceries || !cab || !utilities) return;

    await tx.insert(expenseParticipantsTable).values([
      ...[aarav, diya, kabir, meera].map((member) => ({
        expenseId: groceries.id,
        memberId: member.id,
      })),
      ...[aarav, diya, kabir, meera].map((member) => ({
        expenseId: cab.id,
        memberId: member.id,
      })),
      ...[aarav, diya, kabir, meera].map((member) => ({
        expenseId: utilities.id,
        memberId: member.id,
      })),
    ]);
  });
}