import { clerkClient, getAuth } from "@clerk/express";
import type { Request, Response } from "express";
import { eq } from "drizzle-orm";
import { db, membersTable, usersTable, type User } from "@workspace/db";

export async function getCurrentUser(req: Request): Promise<User | null> {
  const { userId } = getAuth(req);
  if (!userId) return null;

  const clerkUser = await clerkClient.users.getUser(userId);
  const email =
    clerkUser.primaryEmailAddress?.emailAddress ??
    `${userId.replace(/[^a-zA-Z0-9]/g, "").slice(0, 40)}@student.local`;
  const name =
    clerkUser.fullName?.trim() ||
    clerkUser.firstName?.trim() ||
    email.split("@")[0] ||
    "Student";

  const [existing] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.clerkUserId, userId))
    .limit(1);

  const user =
    existing ??
    (
      await db
        .insert(usersTable)
        .values({ clerkUserId: userId, name, email })
        .returning()
    )[0];
  if (!user) return null;

  if (user.name !== name || user.email !== email) {
    const [updated] = await db
      .update(usersTable)
      .set({ name, email })
      .where(eq(usersTable.id, user.id))
      .returning();
    if (updated) return claimPendingMemberships(updated);
  }
  return claimPendingMemberships(user);
}

async function claimPendingMemberships(user: User) {
  await db
    .update(membersTable)
    .set({ userId: user.id, name: user.name })
    .where(eq(membersTable.email, user.email));
  return user;
}

export async function requireCurrentUser(req: Request, res: Response) {
  try {
    const user = await getCurrentUser(req);
    if (!user) {
      res.status(401).json({ error: "Sign in to continue." });
      return null;
    }
    return user;
  } catch (error) {
    req.log.error({ err: error }, "Unable to load current user");
    res.status(401).json({ error: "Unable to verify your account." });
    return null;
  }
}