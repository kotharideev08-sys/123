import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  numeric,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const usersTable = pgTable(
  "campus_users",
  {
    id: serial("id").primaryKey(),
    clerkUserId: varchar("clerk_user_id", { length: 255 }).notNull(),
    name: varchar("name", { length: 120 }).notNull(),
    email: varchar("email", { length: 255 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    clerkUserIdIdx: uniqueIndex("campus_users_clerk_user_id_idx").on(table.clerkUserId),
    emailIdx: uniqueIndex("campus_users_email_idx").on(table.email),
  }),
);

export const groupsTable = pgTable(
  "expense_groups",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    emoji: varchar("emoji", { length: 12 }).notNull().default("◌"),
    inviteCode: varchar("invite_code", { length: 16 }),
    adminUserId: integer("admin_user_id").references(() => usersTable.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    inviteCodeIdx: uniqueIndex("expense_groups_invite_code_idx").on(table.inviteCode),
  }),
);

export const membersTable = pgTable(
  "expense_members",
  {
    id: serial("id").primaryKey(),
    groupId: integer("group_id").notNull().references(() => groupsTable.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => usersTable.id, { onDelete: "set null" }),
    name: varchar("name", { length: 120 }).notNull(),
    email: varchar("email", { length: 255 }),
    role: varchar("role", { length: 20 }).notNull().default("member"),
  },
  (table) => ({
    groupEmailIdx: uniqueIndex("expense_members_group_email_idx").on(table.groupId, table.email),
  }),
);

export const expensesTable = pgTable("shared_expenses", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull().references(() => groupsTable.id, { onDelete: "cascade" }),
  description: varchar("description", { length: 180 }).notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  paidByMemberId: integer("paid_by_member_id").notNull().references(() => membersTable.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const expenseParticipantsTable = pgTable(
  "expense_participants",
  {
    expenseId: integer("expense_id").notNull().references(() => expensesTable.id, { onDelete: "cascade" }),
    memberId: integer("member_id").notNull().references(() => membersTable.id, { onDelete: "cascade" }),
    shareAmount: numeric("share_amount", { precision: 12, scale: 2 }),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.expenseId, table.memberId] }),
  }),
);

export const settlementsTable = pgTable("expense_settlements", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull().references(() => groupsTable.id, { onDelete: "cascade" }),
  fromMemberId: integer("from_member_id").notNull().references(() => membersTable.id),
  toMemberId: integer("to_member_id").notNull().references(() => membersTable.id),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const groupsRelations = relations(groupsTable, ({ one, many }) => ({
  admin: one(usersTable, {
    fields: [groupsTable.adminUserId],
    references: [usersTable.id],
  }),
  members: many(membersTable),
  expenses: many(expensesTable),
}));

export const usersRelations = relations(usersTable, ({ many }) => ({
  groups: many(groupsTable),
  memberships: many(membersTable),
}));

export const membersRelations = relations(membersTable, ({ one, many }) => ({
  group: one(groupsTable, {
    fields: [membersTable.groupId],
    references: [groupsTable.id],
  }),
  user: one(usersTable, {
    fields: [membersTable.userId],
    references: [usersTable.id],
  }),
  paidExpenses: many(expensesTable),
}));

export const expensesRelations = relations(expensesTable, ({ one, many }) => ({
  group: one(groupsTable, {
    fields: [expensesTable.groupId],
    references: [groupsTable.id],
  }),
  paidBy: one(membersTable, {
    fields: [expensesTable.paidByMemberId],
    references: [membersTable.id],
  }),
  participants: many(expenseParticipantsTable),
}));

export const expenseParticipantsRelations = relations(expenseParticipantsTable, ({ one }) => ({
  expense: one(expensesTable, {
    fields: [expenseParticipantsTable.expenseId],
    references: [expensesTable.id],
  }),
  member: one(membersTable, {
    fields: [expenseParticipantsTable.memberId],
    references: [membersTable.id],
  }),
}));

export const settlementsRelations = relations(settlementsTable, ({ one }) => ({
  group: one(groupsTable, {
    fields: [settlementsTable.groupId],
    references: [groupsTable.id],
  }),
  fromMember: one(membersTable, {
    fields: [settlementsTable.fromMemberId],
    references: [membersTable.id],
  }),
  toMember: one(membersTable, {
    fields: [settlementsTable.toMemberId],
    references: [membersTable.id],
  }),
}));

export const insertGroupSchema = createInsertSchema(groupsTable).omit({
  id: true,
  createdAt: true,
});

export const insertMemberSchema = createInsertSchema(membersTable).omit({ id: true });
export const insertExpenseSchema = createInsertSchema(expensesTable).omit({ id: true, createdAt: true });
export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });

export type User = typeof usersTable.$inferSelect;
export type Group = typeof groupsTable.$inferSelect;
export type Member = typeof membersTable.$inferSelect;
export type Expense = typeof expensesTable.$inferSelect;
export type Settlement = typeof settlementsTable.$inferSelect;